export default function HomePage() {
  return (
    <main style={{ fontFamily: 'sans-serif', textAlign: 'center', padding: '50px' }}>
      <h1>🚀 Welcome to JobPilot</h1>
      <p>Your job search starts here.</p>
    </main>
  );
}